(ns Closh.main
  (:require [clojure.string :as str])
  (:import (java.io File)
           (java.util Calendar Date)))
(defn- say [s] (println s))
(defn- say-no-nl [s] (print s) (flush))

(defn- verify-imports! []
  (let [main-ns (the-ns 'Closh.main)
        string-ns (get (ns-aliases main-ns) 'str)
        imported-classes (ns-imports main-ns)
        trim-fn (when string-ns (ns-resolve string-ns 'trim))
        checks {"clojure.string/trim"
                (and trim-fn (= "" (trim-fn " ")))
                "java.io.File"
                (and (= File (get imported-classes 'File))
                     (instance? File (File. ".")))
                "java.util.Calendar"
                (and (= Calendar (get imported-classes 'Calendar))
                     (instance? Calendar (Calendar/getInstance)))
                "java.util.Date"
                (and (= Date (get imported-classes 'Date))
                     (instance? Date (Date.)))}
        failed (for [[import-name works?] checks :when (not works?)]
                 import-name)]
    (when (seq failed)
      (throw (ex-info "Import verification failed"
                      {:failed-imports (vec failed)})))
    true))

(defn- read-line*
  []
  (let [l (read-line)]
    (if (nil? l) (System/exit 0) l)))

(defn- trim [s] (str/trim (or s "")))

(defn- parse-int
  [s]
  (when s
    (when-let [m (re-find #"^\s*([-+]?\d+)" s)]
      (try (Long/parseLong (second m))
           (catch Exception _ nil)))))

(defn- rand-1-to [n] (inc (long (Math/floor (* (rand) n)))))

(defn- strip-quotes [s]
  (let [n (count s)]
    (if (and (>= n 2)
             (or (and (= (first s) \") (= (last s) \"))
                 (and (= (first s) \') (= (last s) \'))))
      (subs s 1 (dec n))
      s)))

(defn- fmt-num [x]
  (let [d (double x)]
    (if (== d (Math/floor d)) (str (long d)) (str d))))

(defn- rand-cmd []
  (say "Welcome to the Random Number Generator.")
  (say "Please type in the maximum number.")
  (let [sides (parse-int (read-line*))]
    (if (and sides (> sides 0))
      (say (str "The number I got was " (rand-1-to sides) "."))
      (say "Enter a valid number."))))

(defn- run-game []
  (let [rand-num (rand-1-to 100)]
    (say "I have a random number in my mind.")
    (say "Your goal is to guess it.")
    (say "What do you think my number is?")
    (say "Hint: The number is between 1-100")
    (loop [attempts 1]
      (let [guess (parse-int (read-line*))]
        (cond
          (nil? guess)
          (do (say "Please enter a valid number.")
              (recur attempts))

          (= guess rand-num)
          (say (str "Correct! You got the number in " attempts " attempts!"))

          (= guess 9999)
          (do (say (str "The number was " rand-num "."))
              (say "Thanks for playing!"))

          :else
          (do (say "Sorry, that is incorrect.")
              (say "What do you think my number is?")
              (say "To quit, just type the number 9999.")
              (recur (inc attempts))))))))

(defn- run-chance []
  (say "Ranking different coding languages based on luck.")
  (say "How does this work?")
  (say "Well, there is a random number that decides what is good.")
  (say "Here is the key: ")
  (say "1: S+")
  (say "2: S")
  (say "3: A")
  (say "4: B")
  (say "5: C")
  (say "6: D")
  (say "7: F")
  (say "What coding language do you give me?")
  (let [lang (read-line*)
        response (rand-1-to 3)]
    (case (int response)
      1 (say (str "Ooh, " lang ", that's a widespread one."))
      2 (say (str lang " is really well-known."))
      3 (say (str "Lots of people use " lang ".")))
    (let [chance (rand-1-to 7)]
      (Thread/sleep 1000)
      (case (int chance)
        1 (say (str "I think " lang " is S+ tier!"))
        2 (say (str "I think " lang " is S tier!"))
        3 (say (str "I think " lang " is A tier!"))
        4 (say (str "I think " lang " is B tier."))
        5 (say (str "I think " lang " is C tier."))
        6 (say (str "I think " lang " is D tier."))
        7 (say (str "I think " lang " is F tier."))))))

(defn- process-multiline-comments
  [input currently-in-comment]
  (let [n (count input)]
    (loop [i 0, in? currently-in-comment, acc ""]
      (if (>= i n)
        [(str/trim acc) in?]
        (if in?
          (if (and (<= i (- n 4)) (= (subs input i (+ i 4)) "{:/}"))
            (recur (+ i 4) false acc)
            (recur (inc i) true acc))
          (cond
            (and (<= i (- n 4)) (= (subs input i (+ i 4)) "{/:}"))
            (recur (+ i 4) true acc)

            (and (<= i (- n 2)) (= (subs input i (+ i 2)) "/:"))
            [(str/trim acc) in?]

            :else
            (recur (inc i) in? (str acc (nth input i)))))))))

(defn- remove-comments [input]
  (let [idx (.indexOf ^String input "/:")
        input (if (and (not= idx -1)
                       (or (= idx 0) (not= (nth input (dec idx)) \{)))
                (subs input 0 idx)
                input)]
    (str/trim input)))

(defn- paren-content
  [s]
  (let [start (inc (.indexOf ^String s "("))
        end (.lastIndexOf ^String s ")")]
    (when (> end start) (subs s start end))))

(defn- cmd [command args] {:command command :args (vec args)})

(defn- split-quoted-args
  [content]
  (loop [i 0, in-q false, qc nil, cur "", parts []]
    (if (>= i (count content))
      (if (pos? (count cur)) (conj parts (str/trim cur)) parts)
      (let [c (nth content i)]
        (cond
          (and (not in-q) (or (= c \") (= c \')))
          (recur (inc i) true c cur parts)

          (and in-q (= c qc))
          (recur (inc i) false nil cur parts)

          (and (not in-q) (= c \,))
          (recur (inc i) in-q qc "" (conj parts (str/trim cur)))

          :else
          (recur (inc i) in-q qc (str cur c) parts))))))

(defn- parse-statement [statement]
  (let [s (str/trim (remove-comments statement))]
    (or
     (when (= s "") (cmd "comment" []))

     (when (or (str/starts-with? s "print(") (str/starts-with? s "println("))
       (when-let [content (paren-content s)]
         (cmd (if (str/starts-with? s "println(") "println" "print")
              [(strip-quotes content)])))

     (when (str/starts-with? s "var ")
       (let [parts (str/split (subs s 4) #"=" -1)]
         (when (= 2 (count parts))
           (let [n (str/trim (first parts))
                 v (str/trim (second parts))
                 v (if (str/ends-with? v ";") (subs v 0 (dec (count v))) v)
                 v (strip-quotes v)]
             (cmd "var" [n v])))))

     (when (str/starts-with? s "file.system.create(")
       (when-let [content (paren-content s)]
         (cmd "file.system.create" (split-quoted-args content))))

     (when (str/starts-with? s "file.system.rewrite(")
       (when-let [content (paren-content s)]
         (cmd "file.system.rewrite" (split-quoted-args content))))

     (when (str/starts-with? s "file.system.show(")
       (when-let [content (paren-content s)]
         (cmd "file.system.show" [(strip-quotes (str/trim content))])))

     (when (str/starts-with? s "file.system.remove(")
       (when-let [content (paren-content s)]
         (cmd "file.system.remove" (split-quoted-args content))))

     (when (str/starts-with? s "math.random(")
       (when-let [content (paren-content s)]
         (cmd "math.random" [(str/trim content)])))


     (when (and (str/starts-with? s "list") (> (.indexOf ^String s "=") 0))
       (let [parts (str/split s #"=" -1)]
         (when (= 2 (count parts))
           (let [lc (str/trim (second parts))]
             (when (and (str/starts-with? lc "[") (str/ends-with? lc "]"))
               (let [inner (subs lc 1 (dec (count lc)))
                     items (map (comp strip-quotes str/trim)
                                (str/split inner #"," -1))]
                 (cmd "list.make" items)))))))

     (when (str/starts-with? s "list.push(")
       (when-let [content (paren-content s)]
         (cmd "list.add" [(strip-quotes (str/trim content))])))

     (when (and (str/starts-with? s "if") (> (.indexOf ^String s "(") 0))
       (let [start (inc (.indexOf ^String s "("))
             end (.indexOf ^String s ")" (int start))]
         (when (> end start)
           (cmd "if" [(str/trim (subs s start end))]))))

     (when (str/starts-with? s "clsh.sleep(")
       (when-let [content (paren-content s)]
         (cmd "sleep" [(str/trim content)])))

     (when (str/starts-with? s "clsh.quit.forceExit(")
       (when-let [content (paren-content s)]
         (cmd "forceExit" [(str/trim content)])))

     (case s
       ("clsh.run" "clsh.run;")   (cmd "run" [])
       ("clsh.wipe" "clsh.wipe;") (cmd "clear" [])
       ("clsh.quit" "clsh.quit;") (cmd "quit" [])
       ("help" "help;")           (cmd "help" [])
       "}"                        (cmd "block.end" [])
       nil)

     (cmd "unknown" [s]))))

(defn- execute-statement [{:keys [command args]} variables list-items]
  (case command
    "println" (let [o (first args)]
                (say (str "> " (get variables o o))))
    "print"   (let [o (first args)]
                (say-no-nl (str "> " (get variables o o) " ")))
    "math.random"
    (when (seq args)
      (let [mx (parse-int (first args))]
        (when (and mx (> mx 0))
          (say (str "> " (rand-1-to mx))))))

    ("list.make" "list.add")
    (say (str "> [" (str/join ", " list-items) "]"))

    "sleep"
    (when (seq args)
      (let [t (parse-int (first args))]
        (when (and t (> t 0))
          (say (str "[SYSTEM] Thread paused for " t " ms"))
          (Thread/sleep (long t))
          (say "[SYSTEM] Thread resumed"))))

    nil))

(defn- size-string [size]
  (cond
    (< size 1024) (str size " B")
    (< size (* 1024 1024))
    (str (fmt-num (/ (Math/round (* (/ size 1024.0) 100)) 100.0)) " KB")
    (< size (* 1024 1024 1024))
    (str (fmt-num (/ (Math/round (* (/ size 1024.0 1024.0) 100)) 100.0)) " MB")
    :else ""))

(defn- write-file! [file-name content]
  (let [file (.getCanonicalFile (File. ^String file-name))
        parent (.getParentFile file)]
    (when (and parent
               (not (.exists parent))
               (not (.mkdirs parent))
               (not (.isDirectory parent)))
      (throw (java.io.IOException.
              (str "Could not create parent directory: " (.getPath parent)))))
    (spit file content)
    file))

(defn- resolve-file [path]
  (let [file (File. ^String path)]
    (if (.isAbsolute file)
      file
      (File. (File. (System/getProperty "user.home") "Downloads") path))))

(defn- downloads-file [file-name]
  (when (or (str/blank? file-name)
            (some #(str/includes? file-name %) ["/" "\\" ":"])
            (#{"." ".."} file-name))
    (throw (IllegalArgumentException.
            "Use a filename only; files created this way are saved in Downloads.")))
  (resolve-file file-name))

(defn- multiline []
  (let [statements   (atom [])
        variables    (atom {})
        list-items   (atom [])
        in-comment   (atom false)
        in-if        (atom false)
        if-condition (atom "")
        if-stmts     (atom [])
        add-stmt!    (fn [p]
                       (if @in-if
                         (swap! if-stmts conj p)
                         (swap! statements conj p)))]
    (loop []
      (let [input (trim (read-line*))
            continue? (atom true)]
        (when-not (= input "")
          (let [[result still-in] (process-multiline-comments input @in-comment)]
            (reset! in-comment still-in)
            (when-not (= result "")
              (let [{:keys [command args] :as parsed} (parse-statement result)]
                (case command
                  "comment" nil

                  ("println" "print" "math.random" "sleep")
                  (add-stmt! parsed)

                  "var"
                  (when (>= (count args) 2)
                    (swap! variables assoc (first args) (second args))
                    (add-stmt! parsed))

                  "file.system.create"
                  (if (>= (count args) 2)
                    (let [fname (first args) content (second args)]
                      (try
                        (let [file (write-file! (.getPath (downloads-file fname)) content)]
                          (swap! variables assoc fname content)
                          (say (str "[SYSTEM] File system Successful! (" (.getPath file) ")")))
                        (catch Exception e
                          (say (str "[ERROR] Failed to create file \"" fname "\": "
                                    (.getMessage e))))))
                    (say "[ERROR] Usage: file.system.create(\"filename\", \"content\")"))

                  "file.system.rewrite"
                  (when (>= (count args) 2)
                    (let [fname (first args) content (second args)]
                      (try
                        (let [file (write-file! (.getPath (resolve-file fname)) content)]
                          (swap! variables assoc fname content)
                          (say (str "[SYSTEM] File rewritten successfully: " (.getPath file))))
                        (catch Exception e
                          (say (str "[ERROR] Failed to rewrite file \"" fname "\": "
                                    (.getMessage e)))))))

                  "file.system.show"
                  (if (>= (count args) 1)
                    (let [path (first args)]
                      (try
                        (let [f (resolve-file path)
                              _ (when-not (.exists f)
                                  (throw (java.io.FileNotFoundException.
                                          (str path " (No such file or directory)"))))
                              content (slurp f)
                              file-type (last (str/split path #"\." -1))
                              cal (doto (Calendar/getInstance)
                                    (.setTime (Date. (.lastModified f))))
                              fdate (str (.get cal Calendar/DAY_OF_MONTH) "/"
                                         (inc (.get cal Calendar/MONTH)) "/"
                                         (.get cal Calendar/YEAR) " "
                                         (.get cal Calendar/HOUR_OF_DAY) ":"
                                         (.get cal Calendar/MINUTE) ":"
                                         (.get cal Calendar/SECOND))]
                          (say "\n[FILE INFORMATION]")
                          (say (str "Filename: " path))
                          (say (str "Type: ." file-type))
                          (say (str "Size: " (size-string (.length f))))
                          (say (str "Last Modified: " fdate))
                          (say "\n[CONTENT]")
                          (say content)
                          (swap! variables assoc path content))
                        (catch Exception e
                          (say (str "[ERROR] Failed to read file: " e)))))
                    (say "[ERROR] Usage: file.system.show(filename.txt)"))

                  "file.system.remove"
                  (if (= (count args) 1)
                    (let [path (first args)]
                      (try
                        (let [f (resolve-file path)]
                          (when-not (.isFile f)
                            (throw (java.io.FileNotFoundException.
                                    (str path " (file does not exist or is not a regular file)"))))
                          (when-not (.delete f)
                            (throw (java.io.IOException. "The file could not be removed.")))
                          (say (str "[SYSTEM] File removed successfully: " (.getPath f))))
                        (catch Exception e
                          (say (str "[ERROR] Failed to remove file \"" path "\": "
                                    (.getMessage e))))))
                    (say "[ERROR] Usage: file.system.remove(\"filename\")"))

                  "list.make"
                  (do (reset! list-items (vec args))
                      (add-stmt! parsed))

                  "list.add"
                  (when (pos? (count args))
                    (swap! list-items conj (first args))
                    (add-stmt! parsed))

                  "if"
                  (when (pos? (count args))
                    (reset! if-condition (first args))
                    (reset! in-if true)
                    (reset! if-stmts []))

                  "block.end"
                  (when @in-if
                    (reset! in-if false)
                    (when (= @if-condition "true")
                      (swap! statements into @if-stmts))
                    (reset! if-stmts []))

                  "help"
                  (do
                    (say "print(\"text\") or println(\"text\") - Print text")
                    (say "var name = value - Create variable")
                    (say "math.random(max) - Generate random number")
                    (say "list = [\"item1\", \"item2\"] - Create list")
                    (say "list.push(\"item\"); - Add to list")
                    (say "if (true) { ... } - Conditional program")
                    (say "clsh.sleep(milliseconds) - Pause execution")
                    (say "file.system.create(\"filename\", \"content\") - Create file in Downloads")
                    (say "file.system.rewrite(\"filename\", \"content\") - Rewrite file in Downloads")
                    (say "file.system.show(\"filename\") - Show file info and content in Downloads")
                    (say "file.system.remove(\"filename\") - Remove a file")
                    (say "clsh.run - Execute all statements")
                    (say "clsh.wipe - Clear all statements")
                    (say "clsh.quit - Return to main menu")
                    (say "clsh.quit.forceExit(errorCode) - Force exit program")
                    (say "/: comment - Single line comment")
                    (say "{/:} \nmultiline \ncomment \n{:/} - Multiline comment"))

                  "run"
                  (do (say "Executing program...")
                      (doseq [stmt @statements]
                        (execute-statement stmt @variables @list-items)))

                  "clear"
                  (do (reset! statements [])
                      (reset! variables {})
                      (reset! list-items [])
                      (say "All statements cleared."))

                  "quit"
                  (do (say "Exiting multiline mode...")
                      (reset! continue? false))

                  "forceExit"
                  (let [code (or (when (seq args) (parse-int (first args))) 0)]
                    (say "Force Exiting...")
                    (System/exit (int code)))

                  "unknown"
                  (when (not= (first args) "")
                    (say (str "[ERROR] Unknown syntax: " (first args))))

                  nil)))))
        (when @continue? (recur))))))

(defn run-main [] 
  (verify-imports!)
  (say "Verified imports: clojure.string, java.io.File, java.util.Calendar, java.util.Date")
  (say "Project Built Successfully")
  (say "Closh Beta v3.25")
  (say "Type 'help' for more info")

  (let [var-name     (atom "")
        var-value    (atom "")
        math-imports (atom 0)
        game-imports (atom 0)]
    (loop []
      (say "Enter your code.")
      (let [code (trim (read-line*))]
        (case code
          ""
          (say "[ERROR] Enter a valid command.")

          "println"
          (let [t (read-line*)]
            (if (= t @var-name)
              (say (str "> " @var-value))
              (say (str "> " t))))

          "print"
          (let [t (read-line*)]
            (if (= t @var-name)
              (say-no-nl (str "> " @var-value " "))
              (say-no-nl (str "> " t " "))))

          "var"
          (do
            (say "Variable name: ")
            (reset! var-name (read-line*))
            (if (zero? (count @var-name))
              (say "Enter a valid command.")
              (do
                (say "Value? (Type is auto-inferred)")
                (reset! var-value (read-line*))
                (say "Variable value set."))))

          "help"
          (do
            (say "Current functions: ")
            (say "Print text: ")
            (say "print")
            (say "Hi!")
            (say "Print text with newline: ")
            (say "println")
            (say "Hi!")
            (say "Create variables: ")
            (say "var")
            (say "VarName")
            (say "Value")
            (say "Print variables: ")
            (say "print")
            (say "VarName")
            (say "Exit program: ")
            (say "exit cmd")
            (say "Error Number")
            (say "Credits: credits")
            (say "Multi-Line: multiline")
            (say "Run: run")
            (say "Imports: ")
            (say "import")
            (say "importName")
            (say "To see import commands, type 'help? imports'"))

          "exit cmd"
          (let [exit-code (or (parse-int (read-line*)) 0)]
            (say "Exiting program.")
            (System/exit (int exit-code)))

          "multiline"
          (multiline)

          "run"
          (do (say "Running program...")
              (run-main))

          "help? imports"
          (do
            (say "Import function 'math.rand', used in 'clsh.math'")
            (say "Import function 'clsh.game', used in 'clsh.game'")
            (say "Import function 'clsh.chance', used in 'clsh.game'"))

          "import"
          (do
            (say "Current imports: ")
            (say "clsh.math")
            (say "clsh.game")
            (say "Enter an import: ")
            (case (trim (read-line*))
              "clsh.math"
              (do (say "Import name 'clsh.math' successfully imported")
                  (say "New command: 'math.rand'")
                  (swap! math-imports inc))
              "clsh.game"
              (do (say "Import name 'clsh.game' successfully imported")
                  (say "New command: 'clsh.game'")
                  (say "New command: 'clsh.chance'")
                  (swap! game-imports inc))
              (say "Unknown import.")))

          "clsh.game"
          (if (zero? @game-imports)
            (say "This command can only be used with the import 'clsh.game'")
            (run-game))

          "clsh.chance"
          (if (zero? @game-imports)
            (say "This command can only be used with the import 'clsh.game'")
            (run-chance))

          "math.rand"
          (if (zero? @math-imports)
            (say "This command can only be used with the import 'clsh.math'")
            (rand-cmd))

          "credits"
          (say "Credits to the creator (Duck.exe). Originally created in Haxe, ported to Clojure.")

          (say (str "[ERROR] Instance '" code "' not found.")))
        (recur)))))

(defn -main [& _args]
  (run-main))