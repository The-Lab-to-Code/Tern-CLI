(defproject Tern "0.1.0"
  :source-paths ["src"]
  :dependencies [[org.clojure/clojure "1.12.0"]]
  :main Tern.main)